package com.example.pizza.adapter;



import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import com.example.pizza.R;

import com.example.pizza.beans.Produit;

import java.util.List;


public class Pizzaadapter extends BaseAdapter {
    private List<Produit> produits;
    private LayoutInflater inflater;

    public Pizzaadapter(List<Produit> produits, Activity activity) {
        this.produits = produits;
        this.inflater = (LayoutInflater) activity.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

    }

    @Override
    public int getCount() {
        return this.produits.size();
    }

    @Override
    public Object getItem(int i) {
        return this.produits.get(i);
    }

    @Override
    public long getItemId(int i) {
        return this.produits.get(i).getId();
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        if(view == null)
            view = inflater.inflate(R.layout.pizza_item, null);

        TextView nom = view.findViewById(R.id.nom);
        TextView nbingrediants = view.findViewById(R.id.nbingrediants);
        TextView duree = view.findViewById(R.id.duree);
        TextView id = view.findViewById(R.id.id);
        ImageView photo = view.findViewById(R.id.photo);

        nom.setText(produits.get(i).getNom());
        nbingrediants.setText(produits.get(i).getNbingrediants()+"");
        duree.setText(produits.get(i).getDuree()+"");
        id.setText(produits.get(i).getId()+"");
        photo.setImageResource(produits.get(i).getPhoto());



        return view;
    }
}
